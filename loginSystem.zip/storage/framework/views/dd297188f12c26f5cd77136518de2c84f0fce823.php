<?php $__env->startSection('content'); ?>

<div class="container custom-login" style="margin-bottom: 5%;" >
    <div class="row">
    <div class="col-sm-5 m-auto d-block col-sm-offset-3">
        <form method="POST" action="<?php echo e(route('login')); ?>"  style="background: rgb(255, 255, 255); padding:20px; border-radius:9px" >
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRq9Ug8Q_LvssBm4JSFQUAGLxJhDRBB1bNRGycWeJBL8w&s" alt="hellos">
            <?php echo csrf_field(); ?>
            <h1>Login Now</h1>
      <div class="mb-3">
        <?php echo csrf_field(); ?>
        <label for="email" class="form-label"><?php echo e(__('Email Address')); ?></label>
        <input type="email"  class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                           <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <br>
      <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label"><?php echo e(__('Enter Password ')); ?></label>
        <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">
       
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
   
</div>
      <br>
      <button type="submit"><?php echo e('Login'); ?></button>
    </form>
    
    </div>
    </div>
    </div >
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\find\resources\views/auth/login.blade.php ENDPATH**/ ?>