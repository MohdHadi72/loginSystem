
<?php /**PATH C:\Users\dell\find\resources\views/welcome.blade.php ENDPATH**/ ?>